<?php
session_start();

// If the user is not logged in as customer, redirect to login page
if (!isset($_SESSION['customer'])) {
    header("Location: customer_login.php");
    exit();
}
?>

<?php
include 'db.php';

$result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer - Browse Products</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Customer - Browse Products</h1>

<table>
    <tr><th>Name</th><th>Price</th><th>Available</th><th>Buy</th></tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['name'] ?></td>
            <td>₹<?= $row['price'] ?></td>
            <td><?= $row['quantity'] ?></td>
            <td>
                <?php if ($row['quantity'] > 0): ?>
                    <a href="buy_product.php?id=<?= $row['id'] ?>">Buy</a>
                <?php else: ?>
                    Out of Stock
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>
<a href="admin.php">Go to Admin Panel</a>
</body>
</html>
