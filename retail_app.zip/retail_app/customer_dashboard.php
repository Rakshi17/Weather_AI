<?php
session_start();
if (!isset($_SESSION["customer"])) {
    header("Location: customer_login.php");
    exit();
}
include("db.php");

// Get product counts for displaying on dashboard
$total_query = "SELECT COUNT(*) as total FROM products";
$total_result = mysqli_query($conn, $total_query);
$total_row = mysqli_fetch_assoc($total_result);
$total_products = $total_row['total'];

// Get recently added products (newest 3)
$recent_query = "SELECT * FROM products ORDER BY id DESC LIMIT 3";
$recent_result = mysqli_query($conn, $recent_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .search-bar {
            margin: 1.5rem 0;
            display: flex;
            gap: 0.5rem;
        }
        .search-bar input {
            flex: 1;
            padding: 0.75rem 1rem;
            border-radius: var(--border-radius);
            border: 1px solid #e5e7eb;
        }
        .welcome-banner {
            background: var(--bg-gradient);
            color: white;
            padding: 2rem;
            border-radius: var(--border-radius);
            margin-bottom: 2rem;
            text-align: center;
        }
        .welcome-banner h2, .welcome-banner p {
            color: white;
            margin-bottom: 1rem;
        }
        .feature-section {
            margin-top: 2rem;
            background: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
        }
        .feature-section h3 {
            margin-bottom: 1rem;
            color: var(--primary);
        }
        .feature-products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
        }
        .feature-product {
            padding: 1rem;
            border: 1px solid #e5e7eb;
            border-radius: var(--border-radius);
            text-align: center;
        }
        .product-price {
            color: var(--primary);
            font-weight: 600;
            margin: 0.5rem 0;
        }
    </style>
</head>
<body>
<div class="dashboard">
    <div class="welcome-banner">
        <h2>Welcome, <?php echo $_SESSION["customer"]; ?> 😊</h2>
        <p>Browse and shop from our collection of <?php echo $total_products; ?> products!</p>
        
        <!-- Quick Search Form -->
        <form action="buy_product.php" method="GET" class="search-bar">
            <input type="text" name="search" placeholder="Search for products..." required>
            <button type="submit" class="button">🔍 Search</button>
        </form>
    </div>

    <div class="card-group">
        <a href="buy_product.php" class="card">
            <h3>🛒 All Products</h3>
            <p>View and purchase from our complete catalog.</p>
        </a>
        <a href="buy_product.php?sort=price_low" class="card">
            <h3>💰 Best Deals</h3>
            <p>Shop our most affordable products.</p>
        </a>
        <a href="buy_product.php?sort=newest" class="card">
            <h3>🆕 New Arrivals</h3>
            <p>Check out our latest products.</p>
        </a>
        <a href="logout.php" class="card logout">
            <h3>🚪 Logout</h3>
        </a>
    </div>
    
    <!-- Recently Added Products -->
    <?php if(mysqli_num_rows($recent_result) > 0): ?>
    <div class="feature-section">
        <h3>🆕 Recently Added Products</h3>
        <div class="feature-products">
            <?php while($row = mysqli_fetch_assoc($recent_result)): ?>
            <div class="feature-product">
                <div><?= htmlspecialchars($row['name']); ?></div>
                <div class="product-price">₹<?= number_format($row['price'], 2); ?></div>
                <a href="buy_product.php?search=<?= urlencode($row['name']); ?>" class="button">View Details</a>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>