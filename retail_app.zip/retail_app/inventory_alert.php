<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}
include("db.php");

// Threshold value for low inventory
$threshold = 5;

// Fetch products below threshold
$query = "SELECT * FROM products WHERE quantity <= $threshold";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Inventory Alert</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>⚠️ Inventory Alerts</h2>
    <?php if (mysqli_num_rows($result) > 0) { ?>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Name</th>
                    <th>Price (₹)</th>
                    <th>Quantity Left</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td>₹<?= $row['price'] ?></td>
                    <td style="color: red; font-weight: bold;"><?= $row['quantity'] ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p style="color: green; font-size: 18px;">✅ All products are sufficiently stocked!</p>
    <?php } ?>
    <br>
    <a href="admin_dashboard.php" class="button">🔙 Back to Dashboard</a>
</div>
</body>
</html>
