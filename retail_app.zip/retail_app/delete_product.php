<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}
include("db.php");

// Delete logic
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delete_query = "DELETE FROM products WHERE id = '$id'";
    mysqli_query($conn, $delete_query);
    header("Location: delete_product.php?msg=deleted");
}

// Fetch products
$product_query = "SELECT * FROM products";
$result = mysqli_query($conn, $product_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Product</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>🗑️ Delete Product</h2>
    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') echo "<p class='message'>Product deleted successfully!</p>"; ?>
    <table class="styled-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price (₹)</th>
                <th>Quantity</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['name'] ?></td>
                <td>₹<?= $row['price'] ?></td>
                <td><?= $row['quantity'] ?></td>
                <td><a href="delete_product.php?id=<?= $row['id'] ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    <br>
    <a href="admin_dashboard.php" class="button">🔙 Back to Dashboard</a>
</div>
</body>
</html>
