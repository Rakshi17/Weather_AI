<?php
session_start();
if (!isset($_SESSION["customer"])) {
    header("Location: customer_login.php");
    exit();
}
include("db.php");

// Search functionality
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$category = isset($_GET['category']) ? mysqli_real_escape_string($conn, $_GET['category']) : '';

// Build the query based on search and category filters
$query = "SELECT * FROM products WHERE 1=1";

if (!empty($search)) {
    $query .= " AND name LIKE '%$search%'";
}

// Default sorting is by name, but can be changed
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'name';
switch ($sort) {
    case 'price_low':
        $query .= " ORDER BY price ASC";
        break;
    case 'price_high':
        $query .= " ORDER BY price DESC";
        break;
    case 'newest':
        $query .= " ORDER BY id DESC";
        break;
    default:
        $query .= " ORDER BY name ASC";
}

$result = mysqli_query($conn, $query);

// For the category dropdown
$category_query = "SELECT DISTINCT 
                    CASE
                        WHEN price > 50000 THEN 'Electronics'
                        WHEN price BETWEEN 10000 AND 50000 THEN 'Home Appliances'
                        WHEN price BETWEEN 2000 AND 9999 THEN 'Fashion & Accessories'
                        WHEN price BETWEEN 500 AND 1999 THEN 'Books & Stationery'
                        ELSE 'Beauty & Personal Care'
                    END AS category
                FROM products ORDER BY category";
$category_result = mysqli_query($conn, $category_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Buy Products</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .search-section {
            background: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow);
        }
        .search-form {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
        }
        .search-input {
            flex: 1;
            min-width: 200px;
        }
        .filter-options {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            flex-wrap: wrap;
            justify-content: center;
        }
        .filter-select {
            padding: 0.5rem;
            border-radius: var(--border-radius);
            border: 1px solid #e5e7eb;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            margin: 1.5rem 0;
        }
        .product-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            border: 1px solid #e5e7eb;
            display: flex;
            flex-direction: column;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow);
        }
        .product-name {
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }
        .product-price {
            color: var(--primary);
            font-weight: 700;
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }
        .product-stock {
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }
        .in-stock {
            color: var(--success);
        }
        .low-stock {
            color: orange;
        }
        .no-stock {
            color: var(--danger);
        }
    </style>
</head>
<body>
<div class="dashboard">
    <h2>🛍️ Shop Products</h2>
    
    <!-- Search and Filter Section -->
    <div class="search-section">
        <form method="GET" action="" class="search-form">
            <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>" class="search-input">
            <button type="submit" class="button">🔍 Search</button>
            <?php if(!empty($search) || !empty($category)): ?>
                <a href="buy_product.php" class="button button-secondary">Clear Filters</a>
            <?php endif; ?>
        </form>
        
        <div class="filter-options">
            <select name="sort" class="filter-select" onchange="this.form.submit()">
                <option value="name" <?php if($sort === 'name') echo 'selected'; ?>>Sort by Name</option>
                <option value="price_low" <?php if($sort === 'price_low') echo 'selected'; ?>>Price: Low to High</option>
                <option value="price_high" <?php if($sort === 'price_high') echo 'selected'; ?>>Price: High to Low</option>
                <option value="newest" <?php if($sort === 'newest') echo 'selected'; ?>>Newest First</option>
            </select>
        </div>
    </div>

    <?php if(mysqli_num_rows($result) > 0): ?>
        
        <!-- Product Display as a Grid -->
        <div class="product-grid">
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="product-card">
                    <div class="product-name"><?= htmlspecialchars($row['name']); ?></div>
                    <div class="product-price">₹<?= number_format($row['price'], 2); ?></div>
                    <div class="product-stock">
                        <?php if($row['quantity'] > 10): ?>
                            <span class="in-stock">✓ In Stock (<?= $row['quantity']; ?> available)</span>
                        <?php elseif($row['quantity'] > 0): ?>
                            <span class="low-stock">⚠ Low Stock (Only <?= $row['quantity']; ?> left)</span>
                        <?php else: ?>
                            <span class="no-stock">✗ Out of Stock</span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if($row['quantity'] > 0): ?>
                        <form action="buy_product.php" method="POST">
                            <input type="hidden" name="product_id" value="<?= $row['id']; ?>">
                            <input type="submit" name="buy" value="Buy Now" class="buy-button">
                        </form>
                    <?php else: ?>
                        <button disabled class="buy-button" style="opacity: 0.5; cursor: not-allowed;">Out of Stock</button>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
        
    <?php else: ?>
        <div class="message info">
            No products found matching your search. Try a different search term or browse all products.
        </div>
    <?php endif; ?>
    
    <br>
    <a href="customer_dashboard.php" class="button">🔙 Back to Dashboard</a>
</div>

<?php
if (isset($_POST['buy'])) {
    $product_id = $_POST['product_id'];

    // Decrease quantity by 1
    $check = mysqli_query($conn, "SELECT quantity FROM products WHERE id = $product_id");
    $data = mysqli_fetch_assoc($check);

    if ($data['quantity'] > 0) {
        mysqli_query($conn, "UPDATE products SET quantity = quantity - 1 WHERE id = $product_id");
        echo "<script>alert('Purchase successful!'); window.location.href='buy_product.php';</script>";
    } else {
        echo "<script>alert('Sorry, product is out of stock');</script>";
    }
}
?>
</body>
</html>