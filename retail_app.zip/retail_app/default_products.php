<?php
include("db.php");

// Check if the 'image_url' column exists in the products table
$check_column_query = "SHOW COLUMNS FROM products LIKE 'image_url'";
$column_result = mysqli_query($conn, $check_column_query);

// If the column doesn't exist, add it
if (mysqli_num_rows($column_result) == 0) {
    $add_column_query = "ALTER TABLE products ADD COLUMN image_url VARCHAR(255)";
    mysqli_query($conn, $add_column_query);
    echo "<div style='text-align:center; padding:10px; background:#d4edda; color:#155724; margin:10px; border-radius:5px;'>
            Added 'image_url' column to the products table.
          </div>";
}

// Check if products already exist to avoid duplicates
$check_query = "SELECT COUNT(*) as count FROM products";
$result = mysqli_query($conn, $check_query);
$row = mysqli_fetch_assoc($result);

// Only add default products if the table is empty or has very few products
if ($row['count'] < 5) {
    
    // Default products array with image URLs (similar to popular e-commerce categories)
    $products = array(
        // Electronics
        array("Samsung Galaxy S23", 74999.00, 15, "images/products/samsung_galaxy_s23.jpg"),
        array("Apple iPhone 15", 79999.00, 10, "images/products/iphone_15.jpg"),
        array("Dell XPS 13 Laptop", 119999.00, 8, "images/products/dell_xps13.jpg"),
        array("Sony WH-1000XM4 Headphones", 22999.00, 20, "images/products/sony_headphones.jpg"),
        array("Xiaomi Smart TV 4K 55\"", 42999.00, 12, "images/products/xiaomi_tv.jpg"),
        
        // Home Appliances
        array("LG 8kg Washing Machine", 31999.00, 7, "images/products/lg_washing_machine.jpg"),
        array("Samsung 260L Refrigerator", 28999.00, 5, "images/products/samsung_refrigerator.jpg"),
        array("Prestige Electric Cooker", 2499.00, 25, "images/products/prestige_cooker.jpg"),
        array("Philips Air Purifier", 9999.00, 15, "images/products/philips_air_purifier.jpg"),
        array("Havells Table Fan", 1999.00, 30, "images/products/havells_fan.jpg"),
        
        // Fashion
        array("Levi's Men's Jeans", 2499.00, 40, "images/products/levis_jeans.jpg"),
        array("Nike Running Shoes", 5999.00, 25, "images/products/nike_shoes.jpg"),
        array("Ray-Ban Sunglasses", 5499.00, 15, "images/products/rayban_sunglasses.jpg"),
        array("Titan Men's Watch", 3499.00, 20, "images/products/titan_watch.jpg"),
        array("Women's Cotton Saree", 1999.00, 30, "images/products/cotton_saree.jpg"),
        
        // Books & Stationery
        array("Atomic Habits Book", 499.00, 50, "images/products/atomic_habits.jpg"),
        array("Parker Pen Set", 899.00, 45, "images/products/parker_pen.jpg"),
        array("Classmate Notebooks Pack", 199.00, 100, "images/products/classmate_notebooks.jpg"),
        array("World Atlas", 699.00, 25, "images/products/world_atlas.jpg"),
        array("Exam Preparation Guide", 459.00, 35, "images/products/exam_guide.jpg"),
        
        // Beauty & Personal Care
        array("Nivea Body Lotion", 349.00, 40, "images/products/nivea_lotion.jpg"),
        array("Dove Shampoo", 399.00, 50, "images/products/dove_shampoo.jpg"),
        array("Lakme Foundation", 599.00, 30, "images/products/lakme_foundation.jpg"),
        array("Men's Grooming Kit", 1299.00, 25, "images/products/grooming_kit.jpg"),
        array("Himalaya Face Wash", 199.00, 60, "images/products/himalaya_facewash.jpg")
    );
    
    // Create the image directory if it doesn't exist
    $dir_path = "images/products";
    if (!file_exists($dir_path)) {
        mkdir($dir_path, 0777, true);
        echo "<div style='text-align:center; padding:10px; background:#d4edda; color:#155724; margin:10px; border-radius:5px;'>
                Created directory for product images: $dir_path
              </div>";
    }
    
    // Insert each product into the database
    foreach ($products as $product) {
        $name = mysqli_real_escape_string($conn, $product[0]);
        $price = $product[1];
        $quantity = $product[2];
        $image_url = mysqli_real_escape_string($conn, $product[3]);
        
        $insert_query = "INSERT INTO products (name, price, quantity, image_url) VALUES ('$name', $price, $quantity, '$image_url')";
        mysqli_query($conn, $insert_query);
    }
    
    echo "<div style='text-align:center; padding:20px; background:#d4edda; color:#155724; margin:20px; border-radius:5px;'>
            <h3>✅ Default products have been added successfully!</h3>
            <p>25 sample products with images have been added to your database.</p>
            <p><strong>Note:</strong> Please upload actual product images to the '$dir_path' directory.</p>
            <a href='admin_dashboard.php' style='display:inline-block; margin-top:15px; padding:10px 20px; background:#28a745; color:white; text-decoration:none; border-radius:5px;'>Return to Dashboard</a>
          </div>";
} else {
    echo "<div style='text-align:center; padding:20px; background:#cce5ff; color:#004085; margin:20px; border-radius:5px;'>
            <h3>ℹ️ Products already exist</h3>
            <p>Your database already contains products. No new products were added.</p>
            <a href='admin_dashboard.php' style='display:inline-block; margin-top:15px; padding:10px 20px; background:#007bff; color:white; text-decoration:none; border-radius:5px;'>Return to Dashboard</a>
          </div>";
}
?>