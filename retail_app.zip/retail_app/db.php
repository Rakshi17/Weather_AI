<?php
$host = "localhost";
$user = "root"; // change if different
$pass = ""; // change if password is set
$dbname = "retail_db";

$conn = new mysqli('localhost', 'root', '', 'retail_app');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
