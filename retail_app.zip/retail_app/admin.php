<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
?>
<?php
include 'db.php';

$result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Product Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Admin - Product Management</h1>

<form action="add_product.php" method="POST">
    <input type="text" name="name" placeholder="Product Name" required>
    <input type="number" name="price" placeholder="Price" step="0.01" required>
    <input type="number" name="quantity" placeholder="Quantity" required>
    <button type="submit">Add Product</button>
</form>

<table>
    <tr><th>Name</th><th>Price</th><th>Quantity</th><th>Action</th></tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['name'] ?></td>
            <td>₹<?= $row['price'] ?></td>
            <td><?= $row['quantity'] ?></td>
            <td><a href="delete_product.php?id=<?= $row['id'] ?>">Delete</a></td>
        </tr>
    <?php endwhile; ?>
</table>
<a href="customer.php">Go to Customer View</a>
</body>
</html>
