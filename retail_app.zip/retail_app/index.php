<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retail Application - Login</title>
    <link rel="stylesheet" href="style.css"> <!-- You can link your style.css here -->
</head>
<body>
    <div class="login-container">
        <h2 >Welcome to the Retail Application</h2>
        <div class="button-group">
            <!-- Admin Login Button -->
            <a href="admin_login.php" class="button">Admin Login</a>
            <!-- Customer Login Button -->
            <a href="customer_login.php" class="button">Customer Login</a>
        </div>
    </div>
</body>
</html>