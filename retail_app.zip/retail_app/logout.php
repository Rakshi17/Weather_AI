<?php
session_start();
session_destroy();
header("Location: index.php"); // or wherever your home is
exit();
