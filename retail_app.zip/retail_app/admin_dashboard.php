<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="dashboard">
    <h2>Welcome, Admin <?php echo $_SESSION["admin"]; ?> 🎩</h2>
    <p>Manage store inventory and track sales.</p>

    <div class="card-group">
        <a href="add_product.php" class="card">
            <h3>➕ Add Product</h3>
            <p>Add new items to your inventory.</p>
        </a>
        <a href="default_products.php" class="card">
            <h3>🏪 Add Default Products</h3>
            <p>Add sample products to your store.</p>
        </a>
        <a href="delete_product.php" class="card">
            <h3>❌ Delete Product</h3>
            <p>Remove outdated or sold-out items.</p>
        </a>
        <a href="buy_product.php" class="card">
            <h3>📦 View Products</h3>
            <p>See what customers see.</p>
        </a>
        <a href="inventory_alert.php" class="card">
            <h3>🔔 Inventory Alerts</h3>
            <p>Check low stock products.</p>
        </a>
        <a href="logout.php" class="card logout">
            <h3>🚪 Logout</h3>
        </a>
    </div>
</div>
</body>
</html>