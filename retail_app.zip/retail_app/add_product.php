<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}
include("db.php");

if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $query = "INSERT INTO products (name, price, quantity) VALUES ('$name', '$price', '$quantity')";
    if (mysqli_query($conn, $query)) {
        $message = "Product added successfully!";
    } else {
        $message = "Failed to add product.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="form-container">
    <h2>➕ Add New Product</h2>
    <?php if (isset($message)) echo "<p class='message'>$message</p>"; ?>
    <form method="POST" action="">
        <input type="text" name="name" placeholder="Product Name" required><br><br>
        <input type="number" name="price" placeholder="Price (₹)" required><br><br>
        <input type="number" name="quantity" placeholder="Quantity" required><br><br>
        <input type="submit" name="add" value="Add Product" class="submit-button">
    </form>
    <br>
    <a href="admin_dashboard.php" class="button">🔙 Back to Dashboard</a>
</div>
</body>
</html>
